/* global jQuery */
jQuery(document).ready(function () {
	"use strict";
	
});